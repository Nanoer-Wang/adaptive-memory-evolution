"""Reproducible, resumable benchmark evaluation."""
