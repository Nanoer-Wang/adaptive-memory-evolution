"""Episodic and dynamic memory."""
